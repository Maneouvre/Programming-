<?php
declare(strict_types=1);

return [
    'host' => 'sql203.infinityfree.com',
    'port' => '3306',
    'database' => 'if0_43216368_ecommerceusers',
    'username' => 'if0_43216368',
    'password' => '2008Emmanuel'
];
