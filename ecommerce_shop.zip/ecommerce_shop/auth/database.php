<?php
declare(strict_types=1);

function shopDatabaseConfig(string $defaultDatabase = 'ecommerceusers'): array
{
    $localConfigPath = __DIR__ . '/../config/database.local.php';
    $localConfig = is_file($localConfigPath) ? require $localConfigPath : [];
    if (!is_array($localConfig)) {
        throw new RuntimeException('The local ecommerce database config must return an array.');
    }

    $getSetting = static function (string $environmentVariable, string $key, string $fallback) use ($localConfig): string {
        $environmentValue = getenv($environmentVariable);
        $value = $environmentValue !== false && $environmentValue !== ''
            ? $environmentValue
            : ($localConfig[$key] ?? $fallback);
        if (!is_string($value) || $value === '') {
            throw new RuntimeException("Configure {$environmentVariable} or config/database.local.php.");
        }
        return $value;
    };

    $host = $getSetting('ECOMMERCE_DB_HOST', 'host', 'localhost');
    $port = $getSetting('ECOMMERCE_DB_PORT', 'port', '3306');
    $database = $getSetting('ECOMMERCE_DB_NAME', 'database', $defaultDatabase);
    $username = $getSetting('ECOMMERCE_DB_USER', 'username', 'root');
    $environmentPassword = getenv('ECOMMERCE_DB_PASSWORD');
    $password = $environmentPassword !== false && $environmentPassword !== ''
        ? $environmentPassword
        : ($localConfig['password'] ?? '');
    if (!is_string($password)) {
        throw new RuntimeException('ECOMMERCE_DB_PASSWORD must be a string.');
    }

    if (!ctype_digit($port) || (int)$port < 1 || (int)$port > 65535) {
        throw new RuntimeException('ECOMMERCE_DB_PORT must be a valid TCP port.');
    }
    if (str_contains($password, 'REPLACE_WITH_')) {
        throw new RuntimeException('Set the real database password in hosting configuration.');
    }

    return [
        'host' => $host,
        'port' => (int)$port,
        'database' => $database,
        'username' => $username,
        'password' => $password
    ];
}

function connectShopUsers(): PDO
{
    $config = shopDatabaseConfig();
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ];
    $pdo = new PDO(
        "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset=utf8mb4",
        $config['username'],
        $config['password'],
        $options
    );
    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS users (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(32) NOT NULL UNIQUE,
            pwd VARCHAR(255) NOT NULL,
            email VARCHAR(254) NOT NULL UNIQUE,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    return $pdo;
}
