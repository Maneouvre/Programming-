<?php
declare(strict_types=1);
require __DIR__ . '/require-admin.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Add Product</title>
    <style>
      * { box-sizing: border-box; }
      body {
        margin: 0;
        font-family: Arial, sans-serif;
        background: #f3f4f6;
        color: #111827;
      }
      .topbar {
        position: sticky;
        top: 0;
        z-index: 1000;
        display: flex;
        align-items: center;
        gap: 12px;
        background: #084f2d;
        padding: 14px 20px;
      }
      .topbar a {
        color: #fff;
        text-decoration: none;
        padding: 8px 12px;
        border-radius: 6px;
        font-weight: 600;
      }
      .topbar a.active {
        background: #2563eb;
      }
      .topbar a:hover {
        background: rgba(255,255,255,0.08);
      }
      .page {
        min-height: calc(100vh - 56px);
      }
      iframe {
        width: 100%;
        min-height: calc(100vh - 56px);
        border: 0;
        display: block;
        background: white;
      }
      .user-pill {
        margin-left: auto;
        color: #fff;
        font-size: 14px;
        font-weight: 700;
      }
    </style>
  </head>
  <body>
    <div class="topbar">
      <a href="index.php">Dashboard</a>
      <a class="active" href="add-product.php">Add Product</a>
      <a href="../index.html">Storefront</a>
      <span class="user-pill"><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin', ENT_QUOTES, 'UTF-8'); ?></span>
      <a href="logout.php">Logout</a>
    </div>
    <div class="page">
      <iframe src="../Admin_dashboard_php_sql/product_upload_dashboard/products_upload.php" title="Add product form"></iframe>
    </div>
  </body>
</html>
